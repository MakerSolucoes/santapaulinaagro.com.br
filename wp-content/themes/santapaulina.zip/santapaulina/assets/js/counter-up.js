 $(function() {
  let dataColor = 
     $('.chart').easyPieChart({
       animate: 2000,
       lineWidth: 7,
       lineCap: 'butt',
       scaleColor: false,      
       barColor: '#f0c520',
       trackColor: '#25130F',
     });
 });
