<section id="entrar-contato">
    <div class="container">
        <div class="row text-center">
            <div class="col-xs-12">
                <span>
                    <?php the_field('entrar_contato', 'options'); ?>
                </span>    
                <button class="btn btn-warning">
                    Entrar em contato
                </button>
            </div>
        </div>
    </div>
</section>
