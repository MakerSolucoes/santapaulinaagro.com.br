<section id="main">
    <div class="container-fluid">
        <div class="row text-center">
            <div class="container">
                <div class="col-xs-12">
                    <h2>Conheça a nossa fazenda</h2>
                </div>
                <div class="col-xs-12">
                <iframe src="https://www.youtube.com/embed/<?php the_field('video_url', 'options') ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</section>
