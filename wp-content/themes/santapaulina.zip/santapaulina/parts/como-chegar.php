<section id="como-chegar">
    <div class="container">
        <div class="row text-center">
        <div class="col-xs-12 my-2">
            <h2>Como chegar</h2>
        </div>
        <div class="col-xs-12">
            <iframe src="https://www.google.com/maps/embed?pb=<?php the_field('maps_embed', 'options') ?>"  style="border:0;" allowfullscreen="true" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        </div>
    </div>
</section>
