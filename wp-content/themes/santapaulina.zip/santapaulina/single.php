<?php
get_header();
echo '<div class="container">';
    the_content();
echo '</div>';
get_footer();

?>
